make clean && make derase && make deploy && make zip
